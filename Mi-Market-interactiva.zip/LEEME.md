# Mi Market · Capacitación de vendedores

Abre `index.html` en Chrome, Edge o Firefox. No requiere instalar aplicaciones ni conexión a internet. Mantén la carpeta `recursos` junto a `index.html`.

- Flechas: avanzar o retroceder. N: notas del facilitador.
- Temas: saltar a un módulo. Pantalla completa: proyectar.
- Captura original: abrir en grande la página de referencia.
- Los ejercicios dan retroalimentación y la lista permite marcar preparación. Son simulaciones educativas; no se conectan a Mi Market ni guardan pedidos.
- Imprimir / PDF genera una versión de las 22 diapositivas de capacitación; la interacción se conserva solo en HTML.
- `Mi-Market-capacitacion.pptx`: copia editable, 22 diapositivas y anexo con 24 páginas originales. Las respuestas están en las notas del facilitador. Las capturas del anexo son imágenes.

## Guion sugerido · 35–45 minutos

Preparar: 8 minutos. Visitar: 10 minutos. Vender: 12 minutos. Resolver y cierre: 10 minutos. Pide al grupo justificar sus respuestas antes de revelarlas.

## Validar antes de capacitar

El contenido proviene de `Mi Market - General (1).pdf`, consultado en MMKT. No se ha comprobado la versión actual de la aplicación. Validar política de contraseñas, mínimo de compra de $30.000 por fecha de entrega para congelados y no congelados, vigencia de descuentos y significado operativo de «cuotificado». El material menciona cuatro tipos de requerimientos sin enumerarlos en texto. No se añadieron nombres de categorías no confirmadas.

Las capturas reproducen el documento original: revisar posibles datos de clientes antes de distribuir o publicar. El paquete no está publicado ni enviado a GitHub.

## Diseño

Se sustituyeron páginas densas por mensajes breves, jerarquía tipográfica y recorrido de trabajo. Se conservan las capturas completas como referencia ampliable. La marca se representa tipográficamente; no es una guía de marca oficial.
